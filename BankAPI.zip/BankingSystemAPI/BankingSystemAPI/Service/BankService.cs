﻿
using BankingSystemAPI.Models;
using BankingSystemAPI.Repository;

namespace BankingSystemAPI.Service
{
    public class BankService : IBankService<AdminLogin>
    {
        private readonly IBankRepo<AdminLogin> _bankrepo;

        public BankService(IBankRepo<AdminLogin> _bankrepo)
        {
            this._bankrepo = _bankrepo;
        }
        public async Task<bool> Login(AdminLogin login)
        {
            var logi = await _bankrepo.Login(login);
            if(logi != null)
            {
                return true;
            }
            else
            {
                return false;
            }     
        }

        public async Task<CustomerRegister> CustomerDetails_byUsername(string Username)
        {
            return await _bankrepo.CustomerDetails_byUsername(Username);
        }

        public async Task<IEnumerable<CustomerRegister>> custregdetails_approved()
        {
            return await _bankrepo.custregdetails_approved();
        }
        public async Task<IEnumerable<CustomerRegister>> custDetails()
        {
            return await _bankrepo.custDetails();
        }
        public async Task makeCustomerInactive(string Username)
        {
            await _bankrepo.makeCustomerInactive(Username);
        }
        public async Task makeCustomeractive(string Username)
        {
            await _bankrepo.makeCustomeractive(Username);
        }
        public async Task approveCustomer(string Username)
        {
            await _bankrepo.approveCustomer(Username);
        }
        public async Task rejectCustomer(string Username)
        {
            await _bankrepo.rejectCustomer(Username);
        }
        public async Task<IEnumerable<TransactionDetail>> custTransactions()
        {
            return await _bankrepo.custTransactions();
        }
        public async Task<IEnumerable<TransactionDetail>> custTrasanctionsByUsername(string accno)
        {
            return await _bankrepo.custTrasanctionsByUsername(accno);
        }
    }
}
