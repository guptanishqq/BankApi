﻿using BankingSystemAPI.Models;
using BankingSystemAPI.Repository;

namespace BankingSystemAPI.Service
{
    public class CustomerServ:ICustomerServ<CustomerRegister>
    {
        private readonly ICustomerRepo<CustomerRegister> _custrepo;

        public CustomerServ(ICustomerRepo<CustomerRegister> _custrepo)
        {
            this._custrepo = _custrepo;
        }

        public async Task<string> CustomerLogin(CustomerRegister cr)
        {
            return await _custrepo.CustomerLogin(cr);
        }

        public async Task<bool> CustomerSignup(CustomerRegister cr)
        {
            /*if(await _custrepo.CustomerSignup(cr))
            {
                return true;
            }
            else
            {
                return false;
            }*/
            return await _custrepo.CustomerSignup(cr);
        }

        public async Task<CustomerDetail> ViewBalance(string username)
        {
            return await _custrepo.ViewBalance(username);
        }
        public async Task<string> DepositMoney(CustomerDetail cd)
        {
            return await _custrepo.DepositMoney(cd);
        }
        public async Task<string> WithdrawMoney(CustomerDetail cd)
        {
            return await _custrepo.WithdrawMoney(cd);
        }
        public async Task<string> TransferMoney(string rec_acc, CustomerDetail cd)
        {
            return await _custrepo.TransferMoney(rec_acc, cd);
        }

        public async Task<IEnumerable<TransactionDetail>> accountTransactions(string accno)
        {
            return await _custrepo.accountTransactions(accno);
        }
    }
}
