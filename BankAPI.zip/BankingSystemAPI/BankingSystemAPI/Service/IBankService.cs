﻿using BankingSystemAPI.Models;

namespace BankingSystemAPI.Service
{
    public interface IBankService<AdminLogin>
    {
        Task<bool> Login(AdminLogin login);
        Task<CustomerRegister> CustomerDetails_byUsername(string Username);
        Task<IEnumerable<CustomerRegister>> custregdetails_approved();
        Task<IEnumerable<CustomerRegister>> custDetails();
        Task makeCustomerInactive(string Username);
        Task makeCustomeractive(string Username);
        Task approveCustomer(string Username);
        Task rejectCustomer(string Username);
        Task<IEnumerable<TransactionDetail>> custTransactions();
        Task<IEnumerable<TransactionDetail>> custTrasanctionsByUsername(string accno);
    }
}
