﻿using BankingSystemAPI.Models;
using System.Text;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;

namespace BankingSystemAPI.Repository
{
    public class CustomerRepo:ICustomerRepo<CustomerRegister>
    {
        private readonly BankApplicationContext _db;
        public CustomerRepo(BankApplicationContext db) { _db = db; }

        public async Task<bool> CustomerSignup(CustomerRegister cr)
        {
            CustomerRegister cs = await _db.CustomerRegisters.FindAsync(cr.Username);
            if (cs == null)
            {
                cr.Password = generatehash(cr.Password);
                cr.ApplicationStatus = "Pending";
                cr.Status = "0";
                _db.CustomerRegisters.Add(cr);
                await _db.SaveChangesAsync();
                return true;
            }
            else
            {
                return false;
            }
        }
        public async Task<string> CustomerLogin(CustomerRegister cr)
        {
            var result = await _db.CustomerRegisters.Where(x => x.Username == cr.Username &&
            x.Password == generatehash(cr.Password)).Select(x => x).SingleOrDefaultAsync();
            CustomerRegister cs = await _db.CustomerRegisters.FindAsync(cr.Username);
            if (cs.ApplicationStatus == "Approved")
            {
                if (result != null)
                {
                    return "Login";
                }
                else
                {
                    return "invalid";
                }
            }
            else if (cs.ApplicationStatus == "Pending")
            {
                return "Pending";
            }
            else
            {
                return "Rejected";
            }
        }

        public async Task<CustomerDetail> ViewBalance(string username)
        {
            var res = await _db.CustomerDetails.FirstOrDefaultAsync(x => x.Username == username);
            return res;
        }
        public async Task<string> DepositMoney(CustomerDetail cd)
        {
            var res = await _db.CustomerDetails.FirstOrDefaultAsync(x => x.Username == cd.Username);
            if (res != null)
            {
                if (int.Parse(cd.Balance) > 0)
                {
                    int res1 = int.Parse(cd.Balance) + int.Parse(res.Balance);
                    res.Balance = res1.ToString();
                    _db.CustomerDetails.Update(res);
                    TransactionDetail ts = new TransactionDetail();
                    ts.Name = res.Username;
                    ts.TransactionType = "Deposit";
                    ts.TransactionDate = DateTime.Now;
                    ts.SenAccountNumber = res.AccountNo;
                    ts.RecAccNo = res.AccountNo;
                    ts.Amount = cd.Balance;
                    _db.TransactionDetails.Add(ts);
                    await _db.SaveChangesAsync();
                    return "Success";
                }
                else
                {
                    return "Invalid";
                }
            }
            else
            {
                return "Account";
            }
        }
        public async Task<string> WithdrawMoney(CustomerDetail cd)
        {
            var res = await _db.CustomerDetails.FirstOrDefaultAsync(x => x.Username == cd.Username);
            if (res != null)
            {
                if (int.Parse(cd.Balance) > 0)
                {
                    if (int.Parse(res.Balance) >= int.Parse(cd.Balance))
                    {
                        int res1 = int.Parse(res.Balance) - int.Parse(cd.Balance);
                        res.Balance = res1.ToString();
                        _db.CustomerDetails.Update(res);
                        TransactionDetail ts = new TransactionDetail();
                        ts.Name = res.Username;
                        ts.TransactionType = "Withdraw";
                        ts.TransactionDate = DateTime.Now;
                        ts.SenAccountNumber = res.AccountNo;
                        ts.RecAccNo = res.AccountNo;
                        ts.Amount = cd.Balance;
                        _db.TransactionDetails.Add(ts);
                        await _db.SaveChangesAsync();
                        
                        return "Success";
                    }
                    else
                    {
                        return "Not";
                    }
                    
                }
                else
                {
                    return "Invalid";
                }
            }
            else
            {
                return "Account";
            }
        }
        public async Task<string> TransferMoney(string rec_acc, CustomerDetail cd)
        {
           
            var res = await _db.CustomerDetails.FirstOrDefaultAsync(x => x.Username == cd.Username);
            
            var res1 = await _db.CustomerDetails.Where(x => x.AccountNo == rec_acc).Select(x => x).SingleOrDefaultAsync();
            var sta = await _db.CustomerRegisters.FirstOrDefaultAsync(x => x.Username == res1.Username);

            if (res1 != null)
            {
                if (int.Parse(cd.Balance) > 0)
                {
                    if (int.Parse(res.Balance) >= int.Parse(cd.Balance))
                    {
                        if (sta.Status == "1")
                        {
                            int res2 = int.Parse(res.Balance) - int.Parse(cd.Balance);
                            int res3 = int.Parse(res1.Balance) + int.Parse(cd.Balance);
                            res.Balance = res2.ToString();
                            res1.Balance = res3.ToString();
                            _db.CustomerDetails.Update(res);
                            _db.CustomerDetails.Update(res1);
                            TransactionDetail ts = new TransactionDetail();
                            ts.Name = res1.Username;
                            ts.TransactionType = "Transfer";
                            ts.TransactionDate = DateTime.Now;
                            ts.SenAccountNumber = res.AccountNo;
                            ts.RecAccNo = res1.AccountNo;
                            ts.Amount = cd.Balance;
                            _db.TransactionDetails.Add(ts);
                            await _db.SaveChangesAsync();
                            /*ViewBag.successmessage = "Money Transfer Successful";
                            return View(res);*/
                            return "1";
                        }
                        else
                        {
                            /*ModelState.AddModelError("", "The Receiver's Account is inactive!");*/
                            return "2";
                        }
                    }
                    else
                    {
                        /*ModelState.AddModelError("", "Not Sufficient Balance!");*/
                        return "3";
                    }
                }
                else
                {
                    /*ModelState.AddModelError("", "Invalid Deposit Amount!");*/
                    return "4";
                }
            }
            else
            {
                return "5";
            }  
        }

        public async Task<IEnumerable<TransactionDetail>> accountTransactions(string accno)
        {
            var result = await _db.TransactionDetails.Where(x => x.SenAccountNumber == accno).ToListAsync();
            return result;
        }

        public string generatehash(string inp)
        {
            SHA256 md5 = SHA256.Create();
            byte[] hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(inp));
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("x2"));
            }
            return sb.ToString();
        }
    }
}
