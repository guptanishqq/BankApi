﻿using BankingSystemAPI.Models;
namespace BankingSystemAPI.Repository
{
    public interface ICustomerRepo<CustomerRegister>
    {
        Task<bool> CustomerSignup(CustomerRegister cr);
        Task<string> CustomerLogin(CustomerRegister cr);
        Task<CustomerDetail> ViewBalance(string username);
        Task<string> DepositMoney(CustomerDetail cd);
        Task<string> WithdrawMoney(CustomerDetail cd);
        Task<string> TransferMoney(string acc_no, CustomerDetail cd);
        Task<IEnumerable<TransactionDetail>> accountTransactions(string accno);
    }
}
