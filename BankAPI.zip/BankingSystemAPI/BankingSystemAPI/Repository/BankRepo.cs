﻿using BankingSystemAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

namespace BankingSystemAPI.Repository
{
    public class BankRepo : IBankRepo<AdminLogin>
    {
        private readonly BankApplicationContext _db;
        public BankRepo(BankApplicationContext db) { _db = db; }
        
        public async Task<AdminLogin> Login(AdminLogin tu)
        {
            AdminLogin result = await _db.AdminLogins.Where(x => x.Username == tu.Username &&
            x.Password == generatehash(tu.Password)).Select(x => x).SingleOrDefaultAsync();
            return result;
        }

        public async Task<CustomerRegister> CustomerDetails_byUsername(string Username)
        {
            return await _db.CustomerRegisters.FindAsync(Username);
        }

        public async Task<IEnumerable<CustomerRegister>> custregdetails_approved()
        {
            var result = await _db.CustomerRegisters.Where(x => x.ApplicationStatus == "Approved").ToListAsync();
            return result;
        }

        public async Task<IEnumerable<CustomerRegister>> custDetails()
        {
            var result = await _db.CustomerRegisters.ToListAsync();
            return result;
        }
        public async Task makeCustomerInactive(string Username)
        {
            CustomerRegister cr = _db.CustomerRegisters.Find(Username);
            cr.Status = "0";
            _db.CustomerRegisters.Update(cr);
            await _db.SaveChangesAsync();
        }
        public async Task makeCustomeractive(string Username)
        {
            CustomerRegister cr = _db.CustomerRegisters.Find(Username);
            cr.Status = "1";
            _db.CustomerRegisters.Update(cr);
            await _db.SaveChangesAsync();
        }

        public async Task approveCustomer(string Username)
        {
            /*CustomerRegister cs = await _db.CustomerRegisters.FindAsync(Username);
            if(cs == null)
            {
                return false;
            }
            else
            {
                cr.ApplicationStatus = "Approved";
                cr.Status = "1";
                _db.CustomerRegisters.Update(cr);
                *//*_db.SaveChanges();*//*

                Random random = new Random();
                int num = random.Next(1000001, 5000000);
                string st = num.ToString();
                CustomerDetail cd = new CustomerDetail();
                cd.Username = Username;
                cd.AccountNo = st;
                cd.Balance = "0";
                cd.Pin = "0";
                _db.CustomerDetails.Add(cd);
                await _db.SaveChangesAsync();
                return true;
            }*/
            CustomerRegister cr = await _db.CustomerRegisters.FindAsync(Username);
            cr.ApplicationStatus = "Approved";
            cr.Status = "1";
            _db.CustomerRegisters.Update(cr);
            /*_db.SaveChanges();*/

            Random random = new Random();
            int num = random.Next(1000001, 5000000);
            string st = num.ToString();
            CustomerDetail cd = new CustomerDetail();
            cd.Username = Username;
            cd.AccountNo = st;
            cd.Balance = "0";
            cd.Pin = "0";
            _db.CustomerDetails.Add(cd);
            await _db.SaveChangesAsync();

        }
        public async Task rejectCustomer(string Username)
        {
            CustomerRegister cr = await _db.CustomerRegisters.FindAsync(Username);
            cr.ApplicationStatus = "Rejected";
            _db.CustomerRegisters.Update(cr);
            await _db.SaveChangesAsync();
        }
        public async Task<IEnumerable<TransactionDetail>> custTransactions()
        {
            var result = await _db.TransactionDetails.ToListAsync();
            return result;
        }
        public async Task<IEnumerable<TransactionDetail>> custTrasanctionsByUsername(string accno)
        {
            var result = await _db.TransactionDetails.Where(x => x.SenAccountNumber == accno).ToListAsync();
            return result;
        }

        public string generatehash(string inp)
        {
            SHA256 md5 = SHA256.Create();
            byte[] hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(inp));
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("x2"));
            }
            return sb.ToString();
        }
    }
}
