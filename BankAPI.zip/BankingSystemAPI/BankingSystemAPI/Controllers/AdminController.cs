﻿using BankingSystemAPI.Models;
using BankingSystemAPI.Service;
using log4net.Config;
using log4net.Core;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Microsoft.Identity.Client;
using System.Reflection;
using NuGet.Protocol.Plugins;

namespace BankingSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IBankService<AdminLogin> _bankservice;
        public AdminController(IBankService<AdminLogin> _bankservice)
        {
            this._bankservice = _bankservice;
        }

        private void LogError(string message)
        {
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
            ILog _logger = LogManager.GetLogger(typeof(LoggerManager));
            _logger.Info(message);
            _logger.Error(message);
            _logger.Debug(message);
        }

        [HttpPost]
        public async Task<IActionResult> AdminLogin(AdminLogin login)
        {
            try
            {
                if (await _bankservice.Login(login))
                {
                    LogError(login.Username+" Login Successful");
                    return Ok("Login Successful");
                }
                else
                {
                    LogError("Invalid Login Credentials");
                    return BadRequest("Check Your Login Credentials");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
            
        }

        [HttpGet("GetCustomerByUsername")]
        public async Task<IActionResult> CustomerDetails_byUsername(string Username)
        {
            try
            {
                if (await _bankservice.custDetails() == null)
                {
                    return NotFound();
                }
                if (await _bankservice.CustomerDetails_byUsername(Username) == null)
                {
                    LogError("User: "+ Username +" :not found");
                    return NotFound("User Not Found");
                }
                LogError("User: " + Username + " :found");
                return Ok(await _bankservice.CustomerDetails_byUsername(Username));
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("GetApprovedCustomers")]
        public async Task<IActionResult> custregdetails_approved()
        {
            try
            {
                var res = await _bankservice.custregdetails_approved();
                if (res.Any())
                {
                    LogError("Approved Customers details");
                    return Ok(res);
                }
                else
                {
                    LogError("No Customers details found");
                    return NotFound("No Data Found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("GetAllCustomers")]
        public async Task<IActionResult> custDetails()
        {
            try
            {
                var res = await _bankservice.custDetails();
                if (res.Any())
                {
                    LogError("Customers details");
                    return Ok(res);
                }
                else
                {
                    LogError("No Customers details found");
                    return NotFound("No Data Found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpPut]
        [Route("makeInactive")]
        public async Task<IActionResult> makeCustInactive(string Username)
        {
            try
            {
                await _bankservice.makeCustomerInactive(Username);
                LogError("User: "+Username+" :made Inactive");
                return Ok("Made Customer Inactive");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpPut]
        [Route("makeactive")]
        public async Task<IActionResult> makeCustactive(string Username)
        {
            try
            {
                await _bankservice.makeCustomeractive(Username);
                LogError("User: " + Username + " :made active");
                return Ok("Made Customer active");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("approveCustomer")]
        public async Task<IActionResult> approveCustomer(string Username)
        {
            try
            {
                /*if (await _bankservice.approveCustomer(Username, cr))
                {
                    return Ok("Customer Approved");
                }
                else
                {
                    *//*return Ok("Customer Not Found");*//*
                    return NotFound("Customer Not Found");
                }  */

                await _bankservice.approveCustomer(Username);
                LogError("User: " + Username + " :Approved");
                return Ok("Customer Approved");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("rejectCustomer")]
        public async Task<IActionResult> rejectCustomer(string Username)
        {
            try
            {
                await _bankservice.rejectCustomer(Username);
                LogError("User: " + Username + " :Rejected");
                return Ok("Customer Rejected");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("GetAllTransactions")]
        public async Task<IActionResult> custTransactions()
        {
            try
            {
                var res = await _bankservice.custTransactions();
                if (res.Any())
                {
                    LogError("All Customers Transactions");
                    return Ok(res);
                }
                else
                {
                    LogError("No Transactions Found");
                    return NoContent();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("GetTransactionsByUsername")]
        public async Task<IActionResult> custTrasanctionsByUsername(string accno)
        {
            try
            {
                var res = await _bankservice.custTrasanctionsByUsername(accno);
                if (res.Any())
                {
                    LogError("User with accno: "+accno+" :Transaction details");
                    return Ok(res);
                }
                else
                {
                    return NotFound("User Not Found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }
    }
}
