﻿using BankingSystemAPI.Models;
using BankingSystemAPI.Service;
using log4net.Config;
using log4net.Core;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NuGet.Protocol.Plugins;
using System.Reflection;

namespace BankingSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerServ<CustomerRegister> _custservice;
        public CustomerController(ICustomerServ<CustomerRegister> _custservice)
        {
            this._custservice = _custservice;
        }

        private void LogError(string message)
        {
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
            ILog _logger = LogManager.GetLogger(typeof(LoggerManager));
            _logger.Info(message);
            _logger.Error(message);
            _logger.Debug(message);
        }

        [HttpPost]
        [Route("CustomerSignUp")]
        public async Task<IActionResult> CustomerSignup(CustomerRegister cr)
        {
            try
            {
                if (await _custservice.CustomerSignup(cr))
                {
                    LogError("User: "+cr.Username+" :Registration send to approval");
                    return Ok("Customer Registration Send to Approval");
                }
                else
                {
                    LogError("Username already exists");
                    return BadRequest("Username already exist");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
            /*await _custservice.CustomerSignup(cr);
            return Ok("Customer Registration Send for Approval");*/
        }

        [HttpPost]
        [Route("CustomerLogin")]
        public async Task<IActionResult> CustomerLogin(CustomerRegister cr)
        {
            try
            {
                if (await _custservice.CustomerLogin(cr) == "Login")
                {
                    LogError("User: " + cr.Username + ":Login Successful");
                    return Ok("Login Successful");
                }
                else if(await _custservice.CustomerLogin(cr) == "invalid")
                {
                    LogError("User Login: "+cr.Username+ " :Invalid Username or Password");
                    return BadRequest("Invalid Username or Password");
                }
                else if (await _custservice.CustomerLogin(cr) == "Pending")
                {
                    LogError("User Login: " + cr.Username + " :Your Application is still pending");
                    return BadRequest("Your Application is still pending");
                }
                else
                {
                    LogError("User Login: " + cr.Username + " :Your Application is Rejected");
                    return BadRequest("Your Application is Rejected");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("ViewBalance")]
        public async Task<IActionResult> ViewBalance(string username)
        {
            var res = await _custservice.ViewBalance(username);
            try
            {
                if (res == null)
                {
                    LogError("User: "+username+" :Not Found");
                    return NotFound("Account Not Found");
                }
                LogError("User: "+username+" :Account Balance");
                return Ok("Balance: "+res.Balance);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("DepositMoney")]
        public async Task<IActionResult> DepositMoney(CustomerDetail cd)
        {
            string res = await _custservice.DepositMoney(cd);
            try
            {
                if (res == "Success")
                {
                    LogError("User: " + cd.Username + " :Money Deposited");
                    return Ok("Money Deposited Successfully");
                }
                else if(res == "Invalid")
                {
                    LogError("User: " + cd.Username + " :Invalid Deposit Amount");
                    return BadRequest("Invalid Deposit Amount");
                }
                else
                {
                    LogError("User: " + cd.Username + " :Account Not Found");
                    return NotFound("Account Not Found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("WithdrawMoney")]
        public async Task<IActionResult> WithdrawMoney(CustomerDetail cd)
        {
            string res = await _custservice.WithdrawMoney(cd);
            try
            {
                if (res == "Success")
                {
                    LogError("User: " + cd.Username + " :Money withdraw successful");
                    return Ok("Money Withdraw Successfully");
                }
                else if (res == "Not")
                {
                    LogError("User: " + cd.Username + " :Not Sufficient balance");
                    return BadRequest("Not Sufficeint Balance");
                }
                else if (res == "Invalid")
                {
                    LogError("User: " + cd.Username + " :Invalid Deposit Amount");
                    return BadRequest("Invalid Deposit Amount");
                }
                else
                {
                    LogError("User: " + cd.Username + " :Account Not Found");
                    return NotFound("Account Not Found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpPost]
        [Route("TransferMoney")]
        public async Task<IActionResult> TransferMoney(string rec_acc, CustomerDetail cd)
        {
            string res = await _custservice.TransferMoney(rec_acc,cd);
            try
            {
                if (res == "1")
                {
                    LogError("User: " + cd.Username + " :Money Transfered Successfully");
                    return Ok("Money Transfer Successfully");
                }
                else if (res == "2")
                {
                    LogError("User: " + cd.Username + " :Receiver's account is inactive");
                    return BadRequest("Receiver's account is inactive");
                }
                else if (res == "3")
                {
                    LogError("User: " + cd.Username + " :Not Sufficient balance");
                    return BadRequest("Not Sufficient Balance");
                }
                else if (res == "4")
                {
                    LogError("User: " + cd.Username + " :Invalid Deposit Amount");
                    return BadRequest("Invalid Deposit Amount");
                }
                else
                {
                    LogError("User: " + cd.Username + " :Account Not Found");
                    return NotFound("Account Not Found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("GetAccountTransactions")]
        public async Task<IActionResult> accountTransactions(string accno)
        {
            try
            {
                var res = await _custservice.accountTransactions(accno);
                if (res.Any())
                {
                    LogError("User with accno: " + accno + " :Transaction Details");
                    return Ok(res);
                }
                else
                {
                    LogError("User with accno: "+accno+" :Not Found");
                    return NotFound("User not Found");
                }
                
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }
    }
}
