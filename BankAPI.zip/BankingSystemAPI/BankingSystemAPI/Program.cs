using BankingSystemAPI.Models;
using BankingSystemAPI.Repository;
using BankingSystemAPI.Service;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddDbContext<BankApplicationContext>(options =>
       options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddScoped<IBankRepo<AdminLogin>, BankRepo>();
builder.Services.AddScoped<IBankService<AdminLogin>, BankService>();
builder.Services.AddScoped<ICustomerRepo<CustomerRegister>, CustomerRepo>();
builder.Services.AddScoped<ICustomerServ<CustomerRegister>, CustomerServ>();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
