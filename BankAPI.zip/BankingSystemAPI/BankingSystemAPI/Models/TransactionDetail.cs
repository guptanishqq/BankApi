﻿using System;
using System.Collections.Generic;

namespace BankingSystemAPI.Models;

public partial class TransactionDetail
{
    public string? Name { get; set; }

    public int TransactionId { get; set; }

    public string? TransactionType { get; set; }

    public DateTime? TransactionDate { get; set; }

    public string? SenAccountNumber { get; set; }

    public string? RecAccNo { get; set; }

    public string? Amount { get; set; }
}
