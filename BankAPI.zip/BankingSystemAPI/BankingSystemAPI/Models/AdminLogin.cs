﻿using System;
using System.Collections.Generic;

namespace BankingSystemAPI.Models;

public partial class AdminLogin
{
    public int Id { get; set; }

    public string? Username { get; set; }

    public string? Password { get; set; }
}
