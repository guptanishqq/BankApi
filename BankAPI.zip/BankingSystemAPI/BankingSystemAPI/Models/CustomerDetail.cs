﻿using System;
using System.Collections.Generic;

namespace BankingSystemAPI.Models;

public partial class CustomerDetail
{
    public string? Username { get; set; }

    public string AccountNo { get; set; } = null!;

    public string? Balance { get; set; }

    public string? Pin { get; set; }

    public virtual CustomerRegister? UsernameNavigation { get; set; }
}
