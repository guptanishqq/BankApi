﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace BankingSystemAPI.Models;

public partial class BankApplicationContext : DbContext
{
    public BankApplicationContext()
    {
    }

    public BankApplicationContext(DbContextOptions<BankApplicationContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AdminLogin> AdminLogins { get; set; }

    public virtual DbSet<CustomerDetail> CustomerDetails { get; set; }

    public virtual DbSet<CustomerRegister> CustomerRegisters { get; set; }

    public virtual DbSet<TblUser> TblUsers { get; set; }

    public virtual DbSet<TransactionDetail> TransactionDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=BankApplication;Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AdminLogin>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__admin_lo__3214EC07F7711497");

            entity.ToTable("admin_login");

            entity.Property(e => e.Password).HasMaxLength(100);
            entity.Property(e => e.Username).HasMaxLength(50);
        });

        modelBuilder.Entity<CustomerDetail>(entity =>
        {
            entity.HasKey(e => e.AccountNo).HasName("PK__customer__B19EBB6225357A21");

            entity.ToTable("customer_details");

            entity.Property(e => e.AccountNo)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("Account_no");
            entity.Property(e => e.Balance)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Pin)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("pin");
            entity.Property(e => e.Username)
                .HasMaxLength(20)
                .IsUnicode(false);

            entity.HasOne(d => d.UsernameNavigation).WithMany(p => p.CustomerDetails)
                .HasForeignKey(d => d.Username)
                .HasConstraintName("FK__customer___Usern__7755B73D");
        });

        modelBuilder.Entity<CustomerRegister>(entity =>
        {
            entity.HasKey(e => e.Username).HasName("PK__customer__536C85E59DD1E5E8");

            entity.ToTable("customer_register");

            entity.Property(e => e.Username)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Address)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ApplicationStatus)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("Application_status");
            entity.Property(e => e.ContactNo)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("contact_no");
            entity.Property(e => e.Email)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.Name)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Panno)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("panno");
            entity.Property(e => e.Password)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(5)
                .IsUnicode(false)
                .HasColumnName("status");
        });

        modelBuilder.Entity<TblUser>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__tbl_user__3214EC07E4F2EEE7");

            entity.ToTable("tbl_user");

            entity.Property(e => e.Password).HasMaxLength(100);
            entity.Property(e => e.Username).HasMaxLength(50);
        });

        modelBuilder.Entity<TransactionDetail>(entity =>
        {
            entity.HasKey(e => e.TransactionId).HasName("PK__transact__9A8C4A3DA24D0488");

            entity.ToTable("transaction_details");

            entity.Property(e => e.TransactionId).HasColumnName("Transaction_id");
            entity.Property(e => e.Amount)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Name)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.RecAccNo)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.SenAccountNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.TransactionDate).HasColumnType("date");
            entity.Property(e => e.TransactionType)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("transaction_type");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
